package co.edu.uelbosque.GenericStore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GenericStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
