package co.edu.uelbosque.GenericStore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GenericStoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(GenericStoreApplication.class, args);
	}

}
